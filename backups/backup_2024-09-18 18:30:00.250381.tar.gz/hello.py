name = input("Enter your Name : ")
print(f"Hello {name}")