day_of_week = input("Enter the day of the week : ").lower()
print(day_of_week)

if day_of_week == "saturday" or day_of_week == "sunday":
    print("Have a great start to the weekend")
else:
    print("Have a hectic day")