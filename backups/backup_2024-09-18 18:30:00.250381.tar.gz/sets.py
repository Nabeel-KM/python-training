my_set = {"Jan", "Feb", "Mar"}

for set in my_set:
    print(set)

my_set.add("Apr")

for set in my_set:
    print(set)

print(my_set)

my_set.remove("Feb")

print(my_set)