my_list= ["Jan", "Feb", "Mar", "Apr"]
for i in my_list:
    print(i)

print(my_list[1])
my_list.append("May")

print(my_list)

for i in my_list:
    print(i)